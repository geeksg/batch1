package com.cg.ClassDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertExample {
	public static void main(String[] args) {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\jyotiras\\Desktop\\VnV 11Apr 2018 Denali BLR\\ALL Materials\\Module 4\\Chrome Driver\\chromedriver.exe");	
	WebDriver driver= new ChromeDriver();
	
	driver.get("file:///C://Users//jyotiras//Desktop//VnV%2011Apr%202018%20Denali%20BLR//ALL%20Materials//Module%204//Lesson%205-HTML%20Pages//Lesson%205-HTML%20Pages//AlertExample.html");
	driver.findElement(By.name("txtName")).click();
	driver.findElement(By.name("txtName")).sendKeys("Hi Shilpa");
	driver.findElement(By.name("btnAlert")).click();
	driver.switchTo().alert();
	}
}
