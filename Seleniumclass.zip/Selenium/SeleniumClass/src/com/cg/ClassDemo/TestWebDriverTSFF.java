package com.cg.ClassDemo;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.*;

public class TestWebDriverTSFF 
{
	public static void main(String[] args) throws InterruptedException 
	{
		WebDriver driver=  new FirefoxDriver();
		driver.get("file:///C:/Users/jyotiras/Desktop/VnV%2011Apr%202018%20Denali%20BLR/ALL%20Materials/Module%204/Lesson%205-HTML%20Pages/Lesson%205-HTML%20Pages/WorkingWithForms.html");
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.close();
	}
}
