package com.cg.ClassDemo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


public class TestWebDriverTSIE {
	public static void main(String[] args) throws InterruptedException 
	{

		System.setProperty("webdriver.ie.driver","C:\\Users\\jyotiras\\Desktop\\VnV 11Apr 2018 Denali BLR\\ALL Materials\\Module 4\\IE Driver\\IEDriverServer.exe");
		WebDriver driver=  new InternetExplorerDriver();
		driver.get("C:\\Users\\jyotiras\\Desktop\\VnV 11Apr 2018 Denali BLR\\ALL Materials\\Module 4\\Lesson 5-HTML Pages\\Lesson 5-HTML Pages\\WorkingWithForms.html");
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.close();
	}

}
