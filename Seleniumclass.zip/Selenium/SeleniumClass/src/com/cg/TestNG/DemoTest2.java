package com.cg.TestNG;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class DemoTest2 extends DemoTestNG1 {
	@BeforeClass
	public void bfrcls()
	{
	System.out.println("Executing before class.");
	}
	  @Test//(priority=1)
	  public void Update() 
	  {
		  System.out.println("Update to app.");
	  }
	  @Test//(priority=2)
	  public void close()
	  {
		  System.out.println("close the app.");
	  }
	  @AfterClass
	  public void afrcls()
	  {
		  System.out.println("Executing after class.");
	  }
}
