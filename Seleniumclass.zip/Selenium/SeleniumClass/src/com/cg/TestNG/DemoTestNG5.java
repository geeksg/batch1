package com.cg.TestNG;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;

public class DemoTestNG5 {
	WebDriver driver;
	@BeforeClass
	public void launchapp()
	{
	System.setProperty("webdriver.chrome.driver","C:\\Users\\jyotiras\\Desktop\\VnV 11Apr 2018 Denali BLR\\ALL Materials\\Module 4\\Chrome Driver\\chromedriver.exe");	
	driver= new ChromeDriver();
	driver.navigate().to("file:///C://Users//jyotiras//Desktop//VnV%2011Apr%202018%20Denali%20BLR//ALL%20Materials//Module%204//Lesson%205-HTML%20Pages//Lesson%205-HTML%20Pages//AlertExample.html");
	}
	@Test
	public void AlertTest()
	{
		driver.findElement(By.name("btnAlert")).click();
		WebDriverWait wait = new WebDriverWait(driver,10);
		wait.until(ExpectedConditions.alertIsPresent()); 
	}
	@AfterClass
	public void closeapp()
	{
		driver.close();
	}
}

