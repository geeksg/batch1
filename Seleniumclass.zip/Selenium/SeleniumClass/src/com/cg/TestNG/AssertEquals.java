package com.cg.TestNG;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class AssertEquals {
	WebDriver driver;
	@BeforeClass
	public void launchapp()
	{
	System.setProperty("webdriver.chrome.driver","C:\\Users\\jyotiras\\Desktop\\VnV 11Apr 2018 Denali BLR\\ALL Materials\\Module 4\\Chrome Driver\\chromedriver.exe");	
	driver= new ChromeDriver();
	driver.navigate().to("file:///C://Users//jyotiras//Desktop//VnV%2011Apr%202018%20Denali%20BLR//ALL%20Materials//Module%204//Lesson%205-HTML%20Pages//Lesson%205-HTML%20Pages//AlertExample.html");
	Assert.assertEquals("Title is not matching","",driver.getTitle());
	}
	@Test
	public void AlertTest()
	{
		driver.findElement(By.name("btnAlert")).click();
		WebDriverWait wait = new WebDriverWait(driver,10);
		wait.until(ExpectedConditions.alertIsPresent()); 
		Alert alert=driver.switchTo().alert();
		alert.accept();
	}
	@AfterClass
	public void closeapp()
	{
		driver.close();
	}

}
