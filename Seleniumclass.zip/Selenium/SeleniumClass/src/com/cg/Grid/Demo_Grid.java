package com.cg.Grid;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class Demo_Grid {
	//public String driverpath="C:\\Users\\jyotiras\\Desktop\\Selenium Jar";
	public static void main(String[] args) throws MalformedURLException {
	//System.setProperty("webdriver.chrome.driver","C:\\Users\\jyotiras\\Desktop\\VnV 11Apr 2018 Denali BLR\\ALL Materials\\Module 4\\Chrome Driver\\chromedriver.exe");	
	//DesiredCapabilities capability = DesiredCapabilities.chrome();
	DesiredCapabilities capability = DesiredCapabilities.firefox();
	capability.setBrowserName("firefox");
	capability.setPlatform(Platform.ANY);
	//capability.setVersion(Version.getVersion());
	//capability.setVersion("50.5");
	
	WebDriver driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"),capability);
						//new RemoteWebDriver(new URL("http://10.220.212."), capability)
	try
	{
		driver.get("http://demo.opencart.com/");
		driver.manage().window().maximize();
	}
	finally{
	}
	
	
	}

}
