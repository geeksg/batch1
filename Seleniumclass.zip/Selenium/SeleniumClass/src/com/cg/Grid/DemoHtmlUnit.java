package com.cg.Grid;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public class DemoHtmlUnit 
{
	public static void main(String[] args) 
	{
		WebDriver driver= new HtmlUnitDriver();
		driver.get("http://demo.opencart.com/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS );
		Boolean title= driver.getTitle().contains("Your Store");
		System.out.println(title);
	}

}
